"use client";

import { useMemo, useState } from "react";
import { cn } from "../utils/cn";

interface ProjectCoverProps {
  slug: string;
  url: string;
  coverImage?: string | null;
  title: string;
  lang: "ar" | "en";
  className?: string;
  imgClassName?: string;
}

function toAbsoluteUrl(raw: string): string {
  if (!raw) return raw;
  return raw.startsWith("http://") || raw.startsWith("https://") ? raw : `https://${raw}`;
}

/**
 * Builds a live screenshot URL for a project using thum.io's free,
 * key-less screenshot endpoint. The target site is rendered on-demand by
 * thum.io's servers and returned as an image, so the cover always works
 * wherever the profile is hosted (no local /covers files required).
 */
function buildLiveScreenshotUrl(targetUrl: string): string {
  const target = toAbsoluteUrl(targetUrl);
  return `https://image.thum.io/get/width/900/crop/680/noanimate/${target}`;
}

/**
 * Renders a live screenshot of the project's own homepage, fetched on the
 * fly from a screenshot service (so it works on any host, including
 * Vercel, without bundling local image files). Falls back to an elegant
 * "Preview unavailable" placeholder if the screenshot can't be loaded.
 */
export function ProjectCover({ url, coverImage, title, lang, className, imgClassName }: ProjectCoverProps) {
  // Only trust `coverImage` when it's already a full, absolute URL (i.e. a
  // real hosted image). Local paths like "/covers/x.jpg" are not bundled
  // with this static profile, so we skip straight to the live screenshot.
  const primarySrc = coverImage && /^https?:\/\//i.test(coverImage) ? coverImage : buildLiveScreenshotUrl(url);
  const fallbackScreenshot = useMemo(() => buildLiveScreenshotUrl(url), [url]);

  const [stage, setStage] = useState<"primary" | "fallback" | "failed">("primary");
  const [loaded, setLoaded] = useState(false);

  if (stage === "failed") {
    return (
      <div
        className={cn(
          "relative flex h-full w-full flex-col items-center justify-center gap-3 bg-gradient-to-br from-[#141418] to-[#0a0a0c] px-6 text-center",
          className
        )}
      >
        <span className="flex h-11 w-11 items-center justify-center rounded-full border border-white/15 bg-white/5 text-white/50">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
            <path d="M3 3l18 18M10.5 10.7A3 3 0 0012 15a3 3 0 002.6-1.5M6.3 6.4C4 8 2.5 10 1.8 12c1.6 4 5.6 7 10.2 7 1.7 0 3.3-.4 4.7-1.1M9.9 4.2A10.8 10.8 0 0112 4c4.6 0 8.6 3 10.2 7-.5 1.2-1.1 2.3-2 3.3" />
          </svg>
        </span>
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-white/55">
          {lang === "ar" ? "المعاينة غير متاحة" : "Preview unavailable"}
        </p>
      </div>
    );
  }

  const src = stage === "primary" ? primarySrc : fallbackScreenshot;

  return (
    <div className={cn("relative h-full w-full overflow-hidden bg-[#111114]", className)}>
      {!loaded && (
        <div className="absolute inset-0 animate-pulse bg-gradient-to-br from-[#17171b] to-[#0a0a0c]" />
      )}
      <img
        key={src}
        src={src}
        alt={title}
        loading="lazy"
        referrerPolicy="no-referrer"
        onLoad={() => setLoaded(true)}
        onError={() => {
          setLoaded(false);
          setStage((prev) => (prev === "primary" ? "fallback" : "failed"));
        }}
        className={cn(
          "h-full w-full object-cover object-top transition-opacity duration-500",
          loaded ? "opacity-100" : "opacity-0",
          imgClassName
        )}
      />
    </div>
  );
}
